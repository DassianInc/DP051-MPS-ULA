# ./controller

This folder contains the controllers

# ./model

This folder contains the models

# ./view

This folder contains the views

# ./store

This folder contains the stores